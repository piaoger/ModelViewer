npm-rm(1) -- Remove a package
=============================

## SYNOPSIS

    npm rm <name>
    npm uninstall <name>

## DESCRIPTION

This uninstalls a package, completely removing everything npm installed
on its behalf.

## SEE ALSO

* npm-prune(1)
* npm-install(1)
* npm-folders(1)
* npm-config(1)
